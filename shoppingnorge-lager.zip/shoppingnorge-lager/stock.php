<?php
/*
Plugin Name: Shopping Norge Lager lokasjoner
Description: Skaper en ny lagerlokasjon som støtter import / eksport samt er primær lager for handel, normalt lager er sekundært. Støtte for PHP 8.2
Version: 1.3
Author: Gustav Öman
*/


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class WC_Secondary_Stock
{

    public function __construct()
    {
        add_action('woocommerce_product_options_inventory_product_data', array($this, 'add_secondary_stock_field'));
        add_action('woocommerce_product_after_variable_attributes', array($this, 'add_secondary_stock_field_variation'), 10, 3);
        add_action('woocommerce_process_product_meta', array($this, 'save_secondary_stock_field'));
        add_action('woocommerce_save_product_variation', array($this, 'save_secondary_stock_field_variation'), 10, 2);
        add_action('woocommerce_before_calculate_totals', array($this, 'reduce_secondary_stock'));
        add_filter('woocommerce_get_availability', array($this, 'custom_stock_display'), 10, 2);
        add_filter('woocommerce_product_get_stock_quantity', array($this, 'adjust_stock_quantity'), 10, 2);
        add_action('woocommerce_single_product_summary', array($this, 'display_custom_stock_levels'), 20);
    }

    // Add secondary stock field to product inventory tab
    public function add_secondary_stock_field()
    {
        echo '<div class="options_group">';

        woocommerce_wp_text_input(array(
            'id' => '_secondary_stock',
            'label' => __('Kragerø Lager', 'woocommerce'),
            'desc_tip' => true,
            'description' => __('Enter the Kragerø stock quantity.', 'woocommerce'),
            'type' => 'number',
            'custom_attributes' => array(
                'min' => '0',
                'step' => '1',
            ),
        ));

        echo '</div>';
    }

    // Add secondary stock field to variable product variations
    public function add_secondary_stock_field_variation($loop, $variation_data, $variation)
    {
        woocommerce_wp_text_input(array(
            'id' => '_secondary_stock[' . $variation->ID . ']',
            'label' => __('Kragerø Lager', 'woocommerce'),
            'desc_tip' => true,
            'description' => __('Enter the Kragerø stock quantity.', 'woocommerce'),
            'type' => 'number',
            'value' => get_post_meta($variation->ID, '_secondary_stock', true),
            'custom_attributes' => array(
                'min' => '0',
                'step' => '1',
            ),
        ));
    }

    // Save the secondary stock field value for single products
    public function save_secondary_stock_field($post_id)
    {
        $secondary_stock = isset($_POST['_secondary_stock']) ? absint($_POST['_secondary_stock']) : '';
        update_post_meta($post_id, '_secondary_stock', $secondary_stock);
    }

    // Save the secondary stock field value for variable products
    public function save_secondary_stock_field_variation($variation_id, $i)
    {
        if (isset($_POST['_secondary_stock'][$variation_id])) {
            $secondary_stock = absint($_POST['_secondary_stock'][$variation_id]);
            update_post_meta($variation_id, '_secondary_stock', $secondary_stock);
        }
    }

    // Reduce the secondary stock when an order is placed
    public function reduce_secondary_stock($cart)
    {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $product_id = $product->get_id();
            if ($product->is_type('variation')) {
                $product_id = $product->get_parent_id();
            }

            $secondary_stock = get_post_meta($product_id, '_secondary_stock', true);
            $primary_stock = $product->get_stock_quantity();
            $quantity_needed = $cart_item['quantity'];

            if ($secondary_stock && $secondary_stock > 0) {
                if ($secondary_stock >= $quantity_needed) {
                    // Deduct all quantity from secondary stock
                    $new_secondary_stock = $secondary_stock - $quantity_needed;
                    update_post_meta($product_id, '_secondary_stock', $new_secondary_stock);
                } else {
                    // Deduct available secondary stock and remaining from primary stock
                    $quantity_needed -= $secondary_stock;
                    update_post_meta($product_id, '_secondary_stock', 0);
                    wc_update_product_stock($product, $primary_stock - $quantity_needed);
                }
            } else {
                // Deduct all quantity from primary stock
                wc_update_product_stock($product, $primary_stock - $quantity_needed);
            }
        }
    }

    // Adjust stock quantity to include secondary stock
    public function adjust_stock_quantity($quantity, $product)
    {
        $secondary_stock = get_post_meta($product->get_id(), '_secondary_stock', true);
        if ($secondary_stock) {
            $quantity += $secondary_stock;
        }
        return $quantity;
    }

    // Custom stock display
    public function custom_stock_display($availability, $product)
    {
        $primary_stock = $product->get_stock_quantity();
        $secondary_stock = get_post_meta($product->get_id(), '_secondary_stock', true);

        if ($product->is_in_stock()) {
            $availability['availability'] = sprintf(__('Nettlager: %d, Kragerø lager: %d', 'woocommerce'), $primary_stock, $secondary_stock);
        }

        return $availability;
    }

    // Display custom stock levels on the product page
    public function display_custom_stock_levels()
    {
        global $product;

        $primary_stock = $product->get_stock_quantity();
        $secondary_stock = get_post_meta($product->get_id(), '_secondary_stock', true);

        if ($product->is_type('variation')) {
            $secondary_stock = get_post_meta($product->get_id(), '_secondary_stock', true);
        }

        echo '<p>' . $this->get_stock_indicator($secondary_stock, 'Kragerø lager') . '</p>';
        echo '<p>' . $this->get_stock_indicator($primary_stock, 'Nettlager') . '</p>';
    }

    // Get stock indicator
    private function get_stock_indicator($stock, $location)
    {
        $color = $stock > 0 ? 'green' : 'red';
        $icon = '<span style="display:inline-block;width:10px;height:10px;background-color:' . $color . ';border-radius:50%;margin-right:5px;"></span>';
        return $icon . $location . ': ' . $stock;
    }
}

new WC_Secondary_Stock();
